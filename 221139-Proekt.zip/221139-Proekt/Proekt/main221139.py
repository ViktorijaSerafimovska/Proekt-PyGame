import pygame
import sys
import random

pygame.init()

pygame.mixer.init()

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
LIGHT_YELLOW = (255, 255, 204)
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Clever Rascals")

pygame.mixer.music.load("background_music.mp3")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1, 0.0)

background = pygame.image.load("background.jpg")
background = pygame.transform.scale(background, (WIDTH, HEIGHT))

font_large = pygame.font.Font(None, 60)
font_small = pygame.font.Font(None, 40)

def draw_text(text, font, color, surface, x, y):
    text_obj = font.render(text, True, color)
    text_rect = text_obj.get_rect(center=(x, y))
    surface.blit(text_obj, text_rect)

def memory_game():
    images = ["a.png", "b.png", "c.png", "d.png", "e.png", "f.png", "g.png"][:6] * 2
    random.shuffle(images)

    loaded_images = [pygame.image.load(img) for img in images]
    positions = [(i % 4 * 150 + 100, i // 4 * 150 + 100) for i in range(12)]
    revealed = [False] * 12
    selected = []

    while True:
        screen.fill((255, 255, 255))
        draw_text("Memory Game", font_large, (0, 0, 0), screen, WIDTH // 2, 50)

        for i, pos in enumerate(positions):
            if revealed[i] or i in selected:
                screen.blit(loaded_images[i], pos)
            else:
                pygame.draw.rect(screen, (100, 100, 255), (*pos, 100, 100))

        return_button = pygame.Rect(WIDTH - 150, HEIGHT - 50, 140, 40)
        pygame.draw.rect(screen, (70, 130, 180), return_button)
        draw_text("Return", font_small, WHITE, screen, WIDTH - 75, HEIGHT - 30)

        again_button = pygame.Rect(WIDTH - 300, HEIGHT - 50, 140, 40)
        pygame.draw.rect(screen, (70, 130, 180), again_button)
        draw_text("Again", font_small, WHITE, screen, WIDTH - 225, HEIGHT - 30)

        pygame.display.flip()

        if len(selected) == 2:
            pygame.time.wait(1000)
            if images[selected[0]] == images[selected[1]]:
                revealed[selected[0]] = True
                revealed[selected[1]] = True
            selected = []

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                x, y = event.pos
                if return_button.collidepoint(x, y):
                    level_screen()
                    return
                if again_button.collidepoint(x, y):
                    memory_game()
                    return

                for i, pos in enumerate(positions):
                    if pos[0] <= x <= pos[0] + 100 and pos[1] <= y <= pos[1] + 100:
                        if not revealed[i] and i not in selected:
                            selected.append(i)
                            if len(selected) > 2:
                                selected = selected[-2:]

        if all(revealed):
            draw_text("You Win!", font_large, (0, 255, 0), screen, WIDTH // 2, HEIGHT // 2)
            pygame.display.flip()
            pygame.time.wait(2000)
            return


def shape_recognition_game():
    shapes = ["Circle", "Square", "Star", "Triangle", "Heart", "Oval"]
    circle_img = pygame.image.load("circle.png")
    square_img = pygame.image.load("square.png")
    star_img = pygame.image.load("star.png")
    triangle_img = pygame.image.load("triangle.png")
    heart_img = pygame.image.load("heart.png")
    oval_img = pygame.image.load("oval.png")

    CELL_SIZE = 150
    shape_images = [pygame.transform.scale(circle_img, (CELL_SIZE, CELL_SIZE)),
                    pygame.transform.scale(square_img, (CELL_SIZE, CELL_SIZE)),
                    pygame.transform.scale(star_img, (CELL_SIZE, CELL_SIZE)),
                    pygame.transform.scale(triangle_img, (CELL_SIZE, CELL_SIZE)),
                    pygame.transform.scale(heart_img, (CELL_SIZE, CELL_SIZE)),
                    pygame.transform.scale(oval_img, (CELL_SIZE, CELL_SIZE))]

    shape_positions = [(i % 3 * (CELL_SIZE + 50) + 100, i // 3 * (CELL_SIZE + 50) + 100) for i in range(len(shapes))]

    word_positions = [(i * 135 + 57, HEIGHT - 70) for i in range(len(shapes))]

    words = ["Circle", "Square", "Star", "Triangle", "Heart", "Oval"]
    random.shuffle(words)

    tick_img = pygame.image.load("tick.png")
    error_img = pygame.image.load("error.png")
    tick_img = pygame.transform.scale(tick_img, (30, 30))
    error_img = pygame.transform.scale(error_img, (30, 30))

    dragged_word = None
    dragged_word_position = None
    correct_matches = []
    word_boxes = {shape: None for shape in shapes}
    error_matches = [None] * len(shapes)

    while True:
        screen.fill(LIGHT_YELLOW)

        pygame.draw.rect(screen, WHITE, (0, 0, WIDTH, 60))
        draw_text("Shape Recognition", font_large, BLACK, screen, WIDTH // 2, 30)

        for i, pos in enumerate(shape_positions):
            screen.blit(shape_images[i], pos)

            pygame.draw.rect(screen, WHITE, (pos[0], pos[1] + CELL_SIZE, CELL_SIZE, 40))

            if word_boxes[shapes[i]] is not None:
                draw_text(word_boxes[shapes[i]], font_small, BLACK, screen, pos[0] + CELL_SIZE // 2,
                          pos[1] + CELL_SIZE + 20)

            if shapes[i] in correct_matches:
                screen.blit(tick_img, (pos[0] + CELL_SIZE - 30, pos[1] + CELL_SIZE - 30))
            elif error_matches[i] is not None:
                screen.blit(error_img, (pos[0] + CELL_SIZE - 30, pos[1] + CELL_SIZE - 30))

        for i, word in enumerate(words):
            word_pos = word_positions[i]
            draw_text(word, font_small, BLACK, screen, word_pos[0], word_pos[1])

            if word == dragged_word:
                dragged_word_position = pygame.mouse.get_pos()
                draw_text(word, font_small, BLACK, screen, dragged_word_position[0], dragged_word_position[1])

        return_button = pygame.Rect(WIDTH - 150, HEIGHT - 50, 140, 40)
        pygame.draw.rect(screen, (70, 130, 180), return_button)
        draw_text("Return", font_small, WHITE, screen, WIDTH - 75, HEIGHT - 30)

        again_button = pygame.Rect(WIDTH - 300, HEIGHT - 50, 140, 40)
        pygame.draw.rect(screen, (70, 130, 180), again_button)
        draw_text("Again", font_small, WHITE, screen, WIDTH - 225, HEIGHT - 30)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_x, mouse_y = event.pos
                if return_button.collidepoint(mouse_x, mouse_y):
                    level_screen()
                    return
                if again_button.collidepoint(mouse_x, mouse_y):
                    shape_recognition_game()
                    return

                for i, word in enumerate(words):
                    word_rect = pygame.Rect(word_positions[i][0] - 50, word_positions[i][1] - 20, 100, 40)
                    if word_rect.collidepoint(mouse_x, mouse_y):
                        dragged_word = word
                        dragged_word_position = (mouse_x, mouse_y)

            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if dragged_word:
                    for i, pos in enumerate(shape_positions):
                        shape_rect = pygame.Rect(pos[0], pos[1], CELL_SIZE, CELL_SIZE)
                        if shape_rect.collidepoint(dragged_word_position):
                            if shapes[i].lower() == dragged_word.lower():
                                correct_matches.append(dragged_word)
                                word_boxes[shapes[i]] = dragged_word
                                error_matches[i] = None
                            else:
                                error_matches[i] = dragged_word
                    dragged_word = None
                    dragged_word_position = None

        if len(correct_matches) == len(shapes):
            draw_text("You Win!", font_large, (0, 255, 0), screen, WIDTH // 2, HEIGHT // 2)
            pygame.display.flip()
            pygame.time.wait(2000)
            return

        pygame.display.flip()


def math_game():
    background = pygame.image.load("background.jpg")
    background = pygame.transform.scale(background, (WIDTH, HEIGHT))

    problems = [
        {'num1': 2, 'num2': 1, 'img': "car.png"},
        {'num1': 3, 'num2': 2, 'img': "strawberry.png"},
        {'num1': 3, 'num2': 3, 'img': "orange.png"},
        {'num1': 4, 'num2': 3, 'img': "turtle.png"},
        {'num1': 2, 'num2': 2, 'img': "ball.png"},
        {'num1': 1, 'num2': 4, 'img': "apple.png"},
        {'num1': 4, 'num2': 4, 'img': "car.png"},
        {'num1': 2, 'num2': 1, 'img': "orange.png"},
        {'num1': 2, 'num2': 4, 'img': "ball.png"}
    ]

    for problem in problems:
        screen.blit(background, (0, 0))
        draw_text("Find the sum", font_large, (0, 0, 255), screen, WIDTH // 2, 100)

        item_img = pygame.image.load(problem['img'])
        item_img = pygame.transform.scale(item_img, (80, 80))
        plus_img = pygame.image.load("plus.png")
        plus_img = pygame.transform.scale(plus_img, (50, 50))

        left_positions = [(WIDTH // 3 - 60, HEIGHT // 3 + i * 90) for i in range(problem['num1'])]
        right_positions = [(WIDTH // 2 + 60, HEIGHT // 3 + i * 90) for i in range(problem['num2'])]
        plus_position = (WIDTH // 2 - 45, HEIGHT // 3 + max(problem['num1'], problem['num2']) * 45 - 25)
        question_box = pygame.Rect(WIDTH // 2 + 130, HEIGHT // 5 + max(problem['num1'], problem['num2']) * 45 - 20, 50,
                                   50)

        answer_choices = [problem['num1'] + problem['num2'], problem['num1'] + problem['num2'] + 1,
                          problem['num1'] + problem['num2'] - 1, problem['num1'] + problem['num2'] + 2]
        random.shuffle(answer_choices)
        answer_positions = [(WIDTH // 2 + 200, HEIGHT // 3 + i * 80) for i in range(len(answer_choices))]
        correct_answer = problem['num1'] + problem['num2']

        selected_answer = None

        while True:
            screen.blit(background, (0, 0))
            draw_text("Find the sum", font_large, (0, 0, 0), screen, WIDTH // 2, 100)

            for pos in left_positions:
                screen.blit(item_img, pos)
            screen.blit(plus_img, plus_position)
            for pos in right_positions:
                screen.blit(item_img, pos)

            for i, answer in enumerate(answer_choices):
                rect = pygame.Rect(answer_positions[i][0] - 40, answer_positions[i][1] - 20, 80, 40)
                pygame.draw.rect(screen, (70, 130, 180), rect)
                draw_text(str(answer), font_small, (255, 255, 255), screen, answer_positions[i][0],
                          answer_positions[i][1])

            return_button = pygame.Rect(WIDTH - 150, HEIGHT - 50, 140, 40)
            pygame.draw.rect(screen, (70, 130, 180), return_button)
            draw_text("Return", font_small, (255, 255, 255), screen, WIDTH - 75, HEIGHT - 30)

            pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    x, y = event.pos
                    if return_button.collidepoint(x, y):
                        level_screen()
                        return
                    for i, rect in enumerate(answer_positions):
                        if pygame.Rect(rect[0] - 40, rect[1] - 20, 80, 40).collidepoint(x, y):
                            selected_answer = answer_choices[i]
                            if selected_answer == correct_answer:
                                draw_text("Correct!", font_large, (0, 255, 0), screen, WIDTH // 2, HEIGHT // 2)
                                pygame.display.flip()
                                pygame.time.wait(2000)
                                break
                            else:
                                draw_text("Try again!", font_large, (255, 0, 0), screen, WIDTH // 2, HEIGHT // 2)
                                pygame.display.flip()
                                pygame.time.wait(2000)
            if selected_answer == correct_answer:
                break


def hello_game():
    TILE_SIZE=130
    GRID_SIZE=3
    LIGHT_PURPLE = (200, 162, 200)
    puzzle_image = pygame.image.load("level1.png")
    puzzle_image = pygame.transform.scale(puzzle_image, (GRID_SIZE * TILE_SIZE, GRID_SIZE * TILE_SIZE))

    pieces = []
    original_positions = []
    grid_positions = []
    outside_positions = []

    for y in range(GRID_SIZE):
        for x in range(GRID_SIZE):
            rect = pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
            piece = puzzle_image.subsurface(rect).copy()
            grid_positions.append((x, y))
            pieces.append({'image': piece, 'grid_pos': (x, y), 'current_pos': None})
            original_positions.append((x, y))

    random.shuffle(pieces)
    outside_positions = [
                            (50, 100 + i * (TILE_SIZE + 10)) for i in range(GRID_SIZE)  # Лево, со малку простор помеѓу
                        ] + [
                            (WIDTH - 150, 100 + i * (TILE_SIZE + 10)) for i in range(GRID_SIZE)
                        ] + [
                            (WIDTH // 4 + i * (TILE_SIZE + 20), HEIGHT - 120) for i in range(GRID_SIZE)
                        ]

    for i, piece in enumerate(pieces):
        piece['current_pos'] = outside_positions[i]

    selected_piece = None
    show_image = False

    while True:
        screen.fill(LIGHT_PURPLE)
        draw_text("Puzzle Game", font_large, (0, 0, 0), screen, WIDTH // 2, 50)

        for x in range(GRID_SIZE):
            for y in range(GRID_SIZE):
                pygame.draw.rect(screen, (0, 0, 0), (x * TILE_SIZE + 200, y * TILE_SIZE + 100, TILE_SIZE, TILE_SIZE), 3)

        for piece in pieces:
            screen.blit(piece['image'], piece['current_pos'])

        return_button = pygame.Rect(WIDTH - 150, HEIGHT - 50, 140, 40)
        pygame.draw.rect(screen, (70, 130, 180), return_button)
        draw_text("Return", font_small, (255, 255, 255), screen, WIDTH - 75, HEIGHT - 30)

        hint_button = pygame.Rect(20, 20, 100, 40)
        pygame.draw.rect(screen, (200, 0, 0), hint_button)
        draw_text("Hint", font_small, (255, 255, 255), screen, 70, 40)

        if show_image:
            screen.blit(puzzle_image,
                        (WIDTH // 2 - (GRID_SIZE * TILE_SIZE) // 2, HEIGHT // 2 - (GRID_SIZE * TILE_SIZE) // 2))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                x, y = event.pos
                if return_button.collidepoint(x, y):
                    return
                if hint_button.collidepoint(x, y):
                    show_image = not show_image
                for piece in pieces:
                    px, py = piece['current_pos']
                    if px <= x <= px + TILE_SIZE and py <= y <= py + TILE_SIZE:
                        selected_piece = piece
                        break
            if event.type == pygame.MOUSEMOTION and selected_piece:
                selected_piece['current_pos'] = (event.pos[0] - TILE_SIZE // 2, event.pos[1] - TILE_SIZE // 2)
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if selected_piece is not None:
                    x, y = event.pos
                    grid_x, grid_y = (x - 200) // TILE_SIZE, (y - 100) // TILE_SIZE
                    if (grid_x, grid_y) in grid_positions:
                        selected_piece['current_pos'] = (grid_x * TILE_SIZE + 200, grid_y * TILE_SIZE + 100)
                    selected_piece = None

        if all(piece['current_pos'] == (piece['grid_pos'][0] * TILE_SIZE + 200, piece['grid_pos'][1] * TILE_SIZE + 100)
               for piece in pieces):
            draw_text("You Win!", font_large, (0, 255, 0), screen, WIDTH // 2, HEIGHT // 2)
            pygame.display.flip()
            pygame.time.wait(2000)
            return


def main_menu():
    while True:
        screen.blit(background, (0, 0))
        draw_text("Clever Rascals", font_large,( 70, 130, 180), screen, WIDTH // 2, HEIGHT // 4)

        mouse_pos = pygame.mouse.get_pos()
        start_button = pygame.Rect(WIDTH // 2 - 150, HEIGHT // 2 - 50, 300, 70)
        rules_button = pygame.Rect(WIDTH // 2 - 150, HEIGHT // 2 + 50, 300, 70)

        pygame.draw.rect(screen, (70, 130, 180) if start_button.collidepoint(mouse_pos) else (100, 149, 237), start_button)
        pygame.draw.rect(screen, (70, 130, 180) if rules_button.collidepoint(mouse_pos) else (100, 149, 237), rules_button)

        draw_text("Start Game", font_small, (255, 255, 255), screen, WIDTH // 2, HEIGHT // 2 - 15)
        draw_text("Rules", font_small, (255, 255, 255), screen, WIDTH // 2, HEIGHT // 2 + 85)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if start_button.collidepoint(mouse_pos):
                    level_screen()
                    return
                if rules_button.collidepoint(mouse_pos):
                    show_rules()
                    return

        pygame.display.flip()



def color_recognition_game():
    TILE_SIZE = 130
    LIGHT_BLUE = (173, 216, 230)
    colors = ["Blue", "Red", "Yellow", "Brown", "Black", "Pink", "Purple", "Green"]
    color_images = [pygame.image.load(f"{color.lower()}.png") for color in colors]
    CELL_SIZE = 120
    color_images = [pygame.transform.scale(pygame.image.load(f"{color.lower()}.png"), (CELL_SIZE, CELL_SIZE)) for color
                    in colors]

    cols = 4
    color_positions = [(i % cols * (CELL_SIZE + 60) + 100, i // cols * (CELL_SIZE + 80) + 100) for i in
                       range(len(colors))]

    word_positions = [(i % cols * (CELL_SIZE + 60) + 100, HEIGHT - 120 if i < 4 else HEIGHT - 70) for i in
                      range(len(colors))]

    words = colors.copy()
    random.shuffle(words)

    tick_img = pygame.transform.scale(pygame.image.load("tick.png"), (30, 30))
    error_img = pygame.transform.scale(pygame.image.load("error.png"), (30, 30))

    dragged_word = None
    dragged_word_position = None
    correct_matches = []
    word_boxes = {color: None for color in colors}
    error_matches = [None] * len(colors)

    while True:
        screen.fill(LIGHT_BLUE)
        pygame.draw.rect(screen, (255, 255, 255), (0, 0, WIDTH, 60))
        draw_text("Color Recognition", font_large, (0, 0, 0), screen, WIDTH // 2, 30)

        for i, pos in enumerate(color_positions):
            screen.blit(color_images[i], pos)

            pygame.draw.rect(screen, (255, 255, 255), (pos[0], pos[1] + CELL_SIZE, CELL_SIZE, 40))

            if word_boxes[colors[i]] is not None:
                draw_text(word_boxes[colors[i]], font_small, (0, 0, 0), screen, pos[0] + CELL_SIZE // 2,
                          pos[1] + CELL_SIZE + 20)

            if colors[i] in correct_matches:
                screen.blit(tick_img, (pos[0] + CELL_SIZE - 30, pos[1] + CELL_SIZE - 30))
            elif error_matches[i] is not None:
                screen.blit(error_img, (pos[0] + CELL_SIZE - 30, pos[1] + CELL_SIZE - 30))

        for i, word in enumerate(words):
            word_pos = word_positions[i]
            if word == dragged_word:
                draw_text(word, font_small, (0, 0, 0), screen, dragged_word_position[0], dragged_word_position[1])
            else:
                draw_text(word, font_small, (0, 0, 0), screen, word_pos[0] + CELL_SIZE // 2, word_pos[1])

        return_button = pygame.Rect(WIDTH - 150, HEIGHT - 50, 140, 40)
        pygame.draw.rect(screen, (70, 130, 180), return_button)
        draw_text("Return", font_small, (255, 255, 255), screen, WIDTH - 75, HEIGHT - 30)

        again_button = pygame.Rect(WIDTH - 300, HEIGHT - 50, 140, 40)
        pygame.draw.rect(screen, (70, 130, 180), again_button)
        draw_text("Again", font_small, (255, 255, 255), screen, WIDTH - 225, HEIGHT - 30)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_x, mouse_y = event.pos

                if return_button.collidepoint(mouse_x, mouse_y):
                    level_screen()
                    return

                if again_button.collidepoint(mouse_x, mouse_y):
                    color_recognition_game()
                    return

                for i, word in enumerate(words):
                    word_rect = pygame.Rect(word_positions[i][0] - 50, word_positions[i][1] - 20, 100, 40)
                    if word_rect.collidepoint(mouse_x, mouse_y):
                        dragged_word = word
                        dragged_word_position = (mouse_x, mouse_y)

            elif event.type == pygame.MOUSEMOTION and dragged_word:
                dragged_word_position = event.pos

            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if dragged_word:
                    for i, pos in enumerate(color_positions):
                        shape_rect = pygame.Rect(pos[0], pos[1], CELL_SIZE, CELL_SIZE)
                        if shape_rect.collidepoint(dragged_word_position):
                            if colors[i].lower() == dragged_word.lower():
                                correct_matches.append(dragged_word)
                                word_boxes[colors[i]] = dragged_word
                                error_matches[i] = None
                            else:
                                error_matches[i] = dragged_word
                    dragged_word = None
                    dragged_word_position = None

        if len(correct_matches) == len(colors):
            draw_text("You Win!", font_large, (0, 255, 0), screen, WIDTH // 2, HEIGHT // 2)
            pygame.display.flip()
            pygame.time.wait(2000)
            return
def show_rules():
    while True:
        screen.blit(background, (0, 0))
        draw_text("Game Rules", font_large, (0, 0, 0), screen, WIDTH // 2, HEIGHT // 6)

        rules = [
            "In this game there are 5 mini games.",
            "1. Memory game, learn about the alphabet.",
            "2. Shape recognition, connect the shapes.",
            "3. Puzzle, connect the picture.",
            "4. Math, learn math quickly.",
            "5. Color, learn about colors."
        ]

        for i, rule in enumerate(rules):
            draw_text(rule, font_small, (0, 0, 0), screen, WIDTH // 2, HEIGHT // 4 + i * 50)

        return_button = pygame.Rect(WIDTH - 150, HEIGHT - 50, 140, 40)
        pygame.draw.rect(screen, (70, 130, 180), return_button)
        draw_text("Return", font_small, (255, 255, 255), screen, WIDTH - 75, HEIGHT - 30)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if return_button.collidepoint(event.pos):
                    main_menu()
                    return


def draw_bold_text(text, font, color, surface, x, y, spacing=2):
    text_surface = font.render(text, True, color)
    text_surface = pygame.transform.scale(text_surface,
                                          (text_surface.get_width() + spacing * len(text), text_surface.get_height()))

    text_rect = text_surface.get_rect(center=(x, y))
    surface.blit(text_surface, text_rect)

def level_screen():
    while True:
        screen.blit(background, (0, 0))
        draw_bold_text("CHOOSE LEVEL", pygame.font.Font(None, 45), (70, 130, 180), screen, WIDTH // 2, HEIGHT // 6,
                       spacing=3)

        mouse_pos = pygame.mouse.get_pos()
        buttons = []
        level_names = ["Memory", "Shapes", "Puzzle", "Math", "Color"]
        level_functions = [memory_game, shape_recognition_game, hello_game, math_game,color_recognition_game]

        for i in range(len(level_names)):
            button = pygame.Rect(WIDTH // 2 - 150, HEIGHT // 4 + i * 80, 300, 70)
            buttons.append((button, level_functions[i]))
            pygame.draw.rect(screen, (70, 130, 180) if button.collidepoint(mouse_pos) else (100, 149, 237), button)
            draw_text(level_names[i], font_small, (255, 255, 255), screen, WIDTH // 2, HEIGHT // 4 + i * 80 + 35)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for button, level_function in buttons:
                    if button.collidepoint(mouse_pos):
                        level_function()
                        return

main_menu()

main_menu()

